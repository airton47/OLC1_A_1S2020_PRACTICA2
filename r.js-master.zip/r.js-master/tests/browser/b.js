define(['c', 'd'], function (c, d) {
    return {
        name: 'b',
        c: c,
        d: d
    };
});
