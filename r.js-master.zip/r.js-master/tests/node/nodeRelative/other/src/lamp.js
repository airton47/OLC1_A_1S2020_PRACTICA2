//Load a node lib that is relative.
define(['../lib/light'], function (light) {
    return {
        name: 'lamp',
        light: light
    };
});
