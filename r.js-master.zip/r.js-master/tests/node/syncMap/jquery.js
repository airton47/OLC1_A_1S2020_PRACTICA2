define(function () {
  return function () { return 'jquery'; };
});
