define(['plug!a'], function (a) {
  return {
    name: 'foo',
    a: a
  };
});
