jjs -scripting ../r.js -- all.js
