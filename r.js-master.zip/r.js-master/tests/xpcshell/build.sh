set -e

../../env/xpcshell/xpcshell build.js
