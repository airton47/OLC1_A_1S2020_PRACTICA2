set -e

../../env/xpcshell/xpcshell run.js
