var requirejs = require('../r.js');

requirejs(['./all']);
