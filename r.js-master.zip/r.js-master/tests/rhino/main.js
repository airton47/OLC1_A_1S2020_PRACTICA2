define(['a'], function (a) {
    return {
        name: 'main',
        a: a
    };
});
